from django.apps import AppConfig


class MonstruosConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "monstruos"
